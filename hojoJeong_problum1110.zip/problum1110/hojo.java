package problum1110;

import java.util.Scanner;

public class hojo {
	 public static void main(String[] args){
	        Scanner sc = new Scanner(System.in);
	        int n = sc.nextInt();
	        int result = n;
	        int cnt = 0;
	        
	        while(true){
	            result = (result%10)*10 + ((result/10) + (result%10))%10;
	            cnt++;
	            
	            if(result == n) break;
	        }
	        
	        System.out.print(cnt);
	        
	    }
}
